<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Delete</h4>
      </div>
      <div class="modal-body">
        <p>Are  YOu Sure Want Delete Image?</p>
      </div>
      <div class="modal-footer">
          <button type="button" class="btn btn-default delete_images" data-dismiss="modal">Delete</button>
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div> 


<!-- Footer -->
                <footer class="footer text-right">
                    <div class="container">
                        <div class="row">
                            <div class="col-xs-12 text-center">
                                © 2016. All rights reserved.
                            </div>
                        </div>
                    </div>
                </footer>
                <!-- End Footer -->

            </div>
        </div>



        <!-- jQuery  -->
        <script src="assets/js/jquery.min.js"></script>
      
        <script>
            
            $(document).ready(function(){
                 $('#datepicker').datepicker();
                 
                 
                 
    $("#addBtn").bind("click", function () {
        var div = $("<div class='control-group add-column xx' />");
        div.html(GetDynamicTextBox(""));

        var _x=$('.xx').length;
         if(_x==0){ 
        $("#TextBoxContainer").after(div);
         }
         else{
            $(".xx").last().after(div);
         } 
           
           
   });
   
   
    $("body").on("click", ".remove", function () {
         //alert(1);
       // $(this).parent().find('.control-group').remove();  
        $(this).closest("div .control-group").remove();
    });
   function GetDynamicTextBox(value) {
    return '<label class="col-md-2 control-label">schdeuled Time</label><div class="controls"> <div class="input-group date" id="datetimepicker3"><input type="text" class="datepicker" name="time[]" placeholder="Time" value="" /></div><input type="text" class="datepicker" name="dance_name[]" placeholder="Dance Name" value=""><input type="text" class="datepicker" name="ins_name[]" placeholder="Insdructer Name" value="">   <input type="button" value="Remove" class="remove btn btn-primary" /></div></div><br>';
$('#datetimepicker3').datetimepicker({
                       use24hours: true,
        format: 'HH:mm'
                });
}

    $("body").on("click", ".remove", function () {
         
       // $(this).parent().find('.control-group').remove();  
        $(this).closest("div .control-group").remove();
    });
                 
            });
           

    
    $(document).on("change", ".cimg", function(e){
               
            var file = this.files[0];
            var fd = new FormData();
            fd.append("file", file);
            // These extra params aren't necessary but show that you can include other data.
            var xhr = new XMLHttpRequest();
            xhr.open('POST', 'upload.php', true);
            xhr.upload.onprogress = function(e) {
                
            };
            xhr.onload = function() {
                $(".cimg").replaceWith($(".cimg").val('').clone(true));

                if (this.status == 200) {
                    var resp = JSON.parse(this.response);
                    if(resp.status==1){
                     $("#category_image").html(resp.result);
                    }
                };
            };
            xhr.send(fd);
           return false;
      });

      $(document).on('click','.delete-image',function(){
    z=this.id;
   $('#myModal').modal();
    $(".delete_images").attr('id', 'delete-image');
    $(".delete_images").attr('data-id', z);

 });
 
 
 
 
 

$(document).on('click','#delete-image',function(){
    
    z= $(this).attr('data-id');
     if(z!=''){
         $.ajax({
                     type: "POST",
                     url: "delete-image.php",
                     data: {file: z},
                     dataType: 'json',
                     success: function (html) {
                         if(html.Status=='Success'){
                            // alert(1);
                             //alert('#'+html.File_Name);
                            $('#'+html.File_Name).remove();

                         }
                         else if(html.Status=='Error'){
                             $('.delete-image').remove();
                         }
                     },

         });
     }
 });
 
 
 
 
  $(document).on("change", ".gimg", function(e){
               
            var file = this.files[0];
            var fd = new FormData();
            fd.append("file", file);
            // These extra params aren't necessary but show that you can include other data.
            var xhr = new XMLHttpRequest();
            xhr.open('POST', 'upload-gallery.php', true);
            xhr.upload.onprogress = function(e) {
                
            };
            xhr.onload = function() {
                $(".gimg").replaceWith($(".gimg").val('').clone(true));

                if (this.status == 200) {
                    var resp = JSON.parse(this.response);
                    if(resp.status==1){
                     $("#category_image").append(resp.result);
                    }
                };
            };
            xhr.send(fd);
           return false;
      });

      $(document).on('click','.delete-gallery',function(){
       //    alert(1);
    z=this.id;
     // alert( z);
   $('#myModal').modal();
    $(".delete_images").attr('id', 'delete-gallery');
    $(".delete_images").attr('data-id', z);

 });

$(document).on('click','#delete-gallery',function(){
    
    
    z= $(this).attr('data-id');
     if(z!=''){
        // alert(1);
         $.ajax({
                     type: "POST",
                     url: "delete-gallery-image.php",
                     data: {file: z},
                     dataType: 'json',
                     success: function (html) {
                         if(html.Status=='Success'){
                                //     e.preventDefault();

                             //alert('#gallery_'+html.File_Name);
                            $('#gallery_'+html.File_Name).remove();

                         }
                         else if(html.Status=='Error'){
                             $('.delete-gallery').remove();
                         }
                     },

         });
     }
 });


   </script>
      <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

    <script>
  $(document).ready(function() {
    $( "#category_image" ).sortable();
    $( "#category_image" ).disableSelection();
  } ); 
   
  
  </script>
        <script src="assets/js/bootstrap.min.js"></script>
          <script src="assets/js/bootstrap-datepicker"></script>
           <script>
            
            $(document).ready(function(){
                 $('#datepicker').datepicker();
            });
            </script>
        <script src="assets/js/detect.js"></script>
        <script src="assets/js/fastclick.js"></script>
        <script src="assets/js/jquery.blockUI.js"></script>
        <script src="assets/js/waves.js"></script>
        <script src="assets/js/jquery.slimscroll.js"></script>
        <script src="assets/js/jquery.scrollTo.min.js"></script>
         <script src="assets/js/modernizr.min.js"></script>
         <script type="text/javascript"
     src="http://tarruda.github.com/bootstrap-datetimepicker/assets/js/bootstrap-datetimepicker.min.js">
    </script>
    
        <script type="text/javascript">
         $(document).ready(function(){
            $(function () {
                $('#datetimepicker3').datetimepicker({
                       use24hours: true,
        format: 'HH:mm'
                });
            });
         })
           
           
  

 
        
        </script>
        <!--<script src="../plugins/switchery/switchery.min.js"></script>

        <!-- Counter js  -->
        <!--<script src="../plugins/waypoints/jquery.waypoints.min.js"></script>
        <script src="../plugins/counterup/jquery.counterup.min.js"></script>-->

        <!--Morris Chart-->
		<!--<script src="../plugins/morris/morris.min.js"></script>
		<script src="../plugins/raphael/raphael-min.js"></script>

        <!-- Dashboard init -->
        <script src="assets/pages/jquery.dashboard.js"></script>

        <!-- App js -->
        <script src="assets/js/jquery.core.js"></script>
        <script src="assets/js/jquery.app.js"></script>

    </body>
</html>