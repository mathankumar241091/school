<?php
session_start();
if(!empty($_SESSION['admin'])){
    session_destroy();
    header('Location:index.php?msg=success');
}
else{
    header('Location:index.php?msg=success');
}

