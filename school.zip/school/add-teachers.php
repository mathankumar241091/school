<?php include_once 'container/header.php';?>
    
            <div class="wrapper">
            <div class="container">
                <div class="row">
                    <div class="col-sm-12">
                        <div class="page-title-box">
                            <h4 class="page-title">Add Teacher</h4>
                        </div>
                    </div>
                </div>
    

                <div class="row">
                    <div class="col-sm-12">
                        <div class="card-box">
                            <h4 class="m-t-0 header-title"><b>Add Teacher</b></h4>
                            
                            <div class="row">
                                <div class="col-md-6">
                                    <?php 
                                    
                                    if(isset($_POST['submit'])){
                                         
                                         $msg=[];
                                         $name=$_POST['name'];
                                         $date=$_POST['date'];
                                         $address=$_POST['address'];
                                         //$image=$_POST['hidden_image'];
                                         
                                         if(empty($name)){
                                             $msg['name']='Enter Teacher Name';
                                         }
                                         if(empty($date)){
                                             $msg['date']='Enter Teacher Date of birth';
                                         }
                                         if(empty($address)){
                                             $msg['address']='Enter Teacher Address';
                                         }
                                         
                                         if(empty($_POST['hidden_image'])){
                                              $msg['images']='Select Teacher Image';
                                         }
                                         if(empty($msg)){
                                             $add_data=array('name'=>$name,'date'=>$date,'address'=>$address,'images'=>implode(',',$_POST['hidden_image']));
                                             $add=$TEACHER->add($add_data);
                                            // echo $add;exit;
                                             if(!empty($add)){
                                                 if($add==1){
                                                     echo '<div class="alert alert-icon alert-success alert-dismissible fade in" role="alert">
                                                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                                            <span aria-hidden="true">×</span>
                                                            </button>
                                                            <i class="mdi mdi-check-all"></i>
                                                            <strong>Success!</strong>Added Successfully
                                                            </div>';
                                                        header('refresh:2;url=Manage-teachers.php');
                                                 }
                                                 else{
                                                      echo '<div class="alert alert-icon alert-warning alert-dismissible fade in" role="alert">
                                                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                                            <span aria-hidden="true">×</span>
                                                             </button>
                                                            <i class="mdi mdi-block-helper"></i>
                                                            <strong>Failure!</strong>OOPS Error.</div>';
                                                         header('refresh:2;url=dashboard.php');
                                                 }
                                             }
                                             else{
                                                  echo '<div class="alert alert-icon alert-warning alert-dismissible fade in" role="alert">
                                                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                                            <span aria-hidden="true">×</span>
                                                             </button>
                                                            <i class="mdi mdi-block-helper"></i>
                                                            <strong>Failure!</strong>OOPS Error.</div>';
                                                   header('refesh:1;url:dashboard.php');
                                             }
                                         }
                                         
                                     }
                                    
                                    
                                    
                                    ?>
                                    
                                    
                                    <form class="form-horizontal" method='post' role="form">
                                        
                                        <div class="form-group">
                                            <label class="col-md-2 control-label">Name</label>
                                            <div class="col-md-10">
                                                <input type="text" name="name" class="form-control"  placeholder="Name" value='<?php if(!empty($name)){ echo $name;}?>'>
                                            </div><br>
                                            
                                        </div>
                                         <div style= 'color:red'><?php if(!empty($msg['name'])){ echo $msg['name'];}?></div>
                                        <div class="form-group">
                                            <label class="col-md-2 control-label">DOB</label>
                                            <div class="col-md-10">
                                                <input type="text" name="date" class="form-control" id="datepicker"  placeholder="DOB" value='<?php if(!empty($date)){ echo $date;}?>'>
                                            </div><br>
                                        </div>
                                          <div style= 'color:red'><?php if(!empty($msg['date'])){ echo $msg['date'];}?></div>
                                        <div class="form-group">
                                            <label class="col-md-2 control-label">Addrss</label>
                                            <div class="col-md-10">
                                                <textarea type="text" name="address" class="form-control"><?php if(!empty($address)){ echo $address;}?></textarea>
                                                  </div><br>
                                        </div>
                                           <div style= 'color:red'><?php if(!empty($msg['address'])){ echo $msg['address'];}?></div>
                                       
                                       
                                        
                                        <div class="form-group">
                                            <label class="col-md-2 control-label">Image</label>
                                                <div class="col-md-10">
                                                    <input  type="file" name="image" class='cimg'><br>
                                                        <div id='category_image'>
                                                            <?php 
                                                            if(isset($_POST['hidden_image'])){
                                                                $images=$_POST['hidden_image'];
                                                            }
                                                            else{
                                                                $images='';
                                                            }
                                                                if(!empty($_POST['hidden_image'])){ 
                                                                    foreach($_POST['hidden_image'] as  $image){
                                                                        $img=explode('.',$image);?>
                                                            <div class="ui-state-default" id=<?php echo $img[0];?>><a class="delete-image" id="<?php echo $image; ?>" title="Delete" href="javascript:void(0);" rel="1" >
                                                            <input type="hidden" id="cat_image" name="hidden_image[]" value="<?php echo $image; ?>">
                                                             <img height="100" width="100" src="upload/banner/<?php echo $image; ?>" alt="" /><i class="glyphicon glyphicon-remove"></i> </a>
                                                               </div> <?php } }?>
                                                       </div>
                                                                                                <?php //echo form_error('order_no','<div class="form-error">','</div>');?>
						</div>
                                                  <div style='color:red'><?php if(!empty($msg['images'])){ echo $msg['images'];}?></div>                                       
					</div>
                                        
                                        <button type="submit" class="btn btn-info waves-effect waves-light" name='submit' value='submit'>Submit</button>
                                    </form>
                                </div>

                                


                            </div>

                    </div>
                    </div>
                </div>

</div>
            </div>

<?php include_once 'container/footer.php'; ?>