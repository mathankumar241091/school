<?php include_once 'container/header.php';?>
    
            <div class="wrapper">
            <div class="container">
                <div class="row">
                    <div class="col-sm-12">
                        <div class="page-title-box">
                            <h4 class="page-title">Edit Teachers</h4>
                        </div>
                    </div>
                </div>
    

                <div class="row">
                    <div class="col-sm-12">
                        <div class="card-box">
                            <h4 class="m-t-0 header-title"><b>Edit Teachers</b></h4>
                            
                            <div class="row">
                                <div class="col-md-6">
                                    <?php 
                                    
                                    if(!empty($_GET['id'])){
                                         $id=$_GET['id'];
                                         $selectid=$TEACHER->SelectId($id);
                                      //   echo $selectid;exit;
                                         if(!empty($selectid)){
                                             foreach($selectid as $select){
                                                 $_Sid=$select['id'];
                                                 $_Sname=$select['name'];
                                                 $dob = date("d/m/Y", strtotime($select['dob']));
                                                 $_Sdate=$dob;
                                                  $_Saddress=$select['address'];
                                                 $_Simages=explode(',',$select['profile_image']);
                                                 if(!empty($_Simages)){
                                                     $_Simages=$_Simages;
                                                 }
                                                 else{
                                                     $_Simages='';
                                                 }
                                                 //var_dump($_Simages);
                                             }
                                         }
                                         else{
                                             echo '<div class="alert alert-icon alert-warning alert-dismissible fade in" role="alert">
                                                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                                            <span aria-hidden="true">×</span>
                                                             </button>
                                                            <i class="mdi mdi-block-helper"></i>
                                                            <strong>Failure!</strong>No Available.</div>';
                                                       header('refresh:0;url=Manage-banner.php');
                                         }
                                         //var_dump($selectid);
                                    }
                                    else{
                                             echo '<div class="alert alert-icon alert-warning alert-dismissible fade in" role="alert">
                                                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                                            <span aria-hidden="true">×</span>
                                                             </button>
                                                            <i class="mdi mdi-block-helper"></i>
                                                            <strong>Failure!</strong>No Available.</div>';
                                                         header('refresh:0;url=Manage-banner.php');
                                         }
                                    
                                    if(isset($_POST['submit'])){
                                         
                                         $msg=[];
                                         $name=$_POST['name'];
                                         $date=$_POST['date'];
                                         $address=$_POST['address'];
                                         //$image=$_POST['hidden_image'];
                                         
                                         if(empty($name)){
                                             $msg['name']='Enter Teacher Name';
                                         }
                                         if(empty($date)){
                                             $msg['date']='Enter Teacher DOB';
                                         }
                                         if(empty($address)){
                                             $msg['address']='Enter Teacher Address';
                                         }
                                         if(empty($_POST['hidden_image'])){
                                              $msg['images']='Select Teacher Images';
                                         }
                                         if(empty($msg)){
                                             $add_data=array('id'=>$_Sid,'name'=>$name,'date'=>$date,'address'=>$address,'images'=>implode(',',$_POST['hidden_image']));
                                             $add=$TEACHER->Update($add_data);
                                             if(!empty($add)){
                                                 if($add==1){
                                                     echo '<div class="alert alert-icon alert-success alert-dismissible fade in" role="alert">
                                                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                                            <span aria-hidden="true">×</span>
                                                            </button>
                                                            <i class="mdi mdi-check-all"></i>
                                                            <strong>Success!</strong>Updated Successfully
                                                            </div>';
                                                        header('refresh:2;url=Manage-teachers.php');
                                                 }
                                                 else{
                                                      echo '<div class="alert alert-icon alert-warning alert-dismissible fade in" role="alert">
                                                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                                            <span aria-hidden="true">×</span>
                                                             </button>
                                                            <i class="mdi mdi-block-helper"></i>
                                                            <strong>Failure!</strong>OOPS Error.</div>';
                                                         header('refresh:2;url=dashboard.php');
                                                 }
                                             }
                                             else{
                                                  echo '<div class="alert alert-icon alert-warning alert-dismissible fade in" role="alert">
                                                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                                            <span aria-hidden="true">×</span>
                                                             </button>
                                                            <i class="mdi mdi-block-helper"></i>
                                                            <strong>Failure!</strong>OOPS Error.</div>';
                                                   header('refesh:1;url:dashboard.php');
                                             }
                                         }
                                         
                                     }
                                    
                                    
                                    
                                    ?>
                                    
                                    
                                    <form class="form-horizontal" method='post' role="form">
                                        
                                        <div class="form-group">
                                            <label class="col-md-2 control-label">Name</label>
                                            <div class="col-md-10">
                                                <input type="text" name="name" class="form-control"  placeholder="Name" value='<?php if(!empty($name)){ echo $name;}elseif(!empty($_Sname)){ echo $_Sname;}?>'>
                                            </div><br>
                                            
                                        </div>
                                        <div style= 'color:red'><?php if(!empty($msg['name'])){ echo $msg['name'];}?></div>
                                          <div class="form-group">
                                            <label class="col-md-2 control-label">Date</label>
                                            <div class="col-md-10">
                                                <input type="text" name="date" class="form-control" id="datepicker"  placeholder="DOB" value='<?php if(!empty($date)){ echo $date;}elseif(!empty($_Sdate)){ echo $_Sdate;}?>'>
                                            </div><br>
                                        </div>
                                          <div style= 'color:red'><?php if(!empty($msg['date'])){ echo $msg['date'];}?></div>
                                        <div class="form-group">
                                            <label class="col-md-2 control-label">Address</label>
                                            <div class="col-md-10">
                                                <textarea type="text" name="address" class="form-control"><?php if(!empty($address)){ echo $address;}elseif(!empty($_Saddress)){ echo $_Saddress;}?></textarea>
                                                  </div><br>
                                        </div>
                                           <div style= 'color:red'><?php if(!empty($msg['address'])){ echo $msg['address'];}?></div>
                                       
                                       
                                        <div class="form-group">
                                            <label class="col-md-2 control-label">Image</label>
                                                <div class="col-md-10">
                                                    <input  type="file" name="image" class='cimg'><br>
                                                        <div id='category_image'>
                                                            <?php 
                                                            if(isset($_POST['hidden_image'])){
                                                                $images=$_POST['hidden_image'];
                                                            }
                                                            else{
                                                                $images=$_Simages;
                                                            }
                                                                if(!empty($images)){ 
                                                                    foreach($images as  $image){
                                                                        if(@getimagesize('upload/event/'.$image)){
                                                                        $img=explode('.',$image);?>
                                                            <div class="ui-state-default" id=<?php echo $img[0];?>><a class="delete-image" id="<?php echo $image; ?>" title="Delete" href="javascript:void(0);" rel="1" >
                                                            <input type="hidden" id="cat_image" name="hidden_image[]" value="<?php echo $image; ?>">
                                                             <img height="100" width="100" src="upload/event/<?php echo $image; ?>" alt="" /><i class="glyphicon glyphicon-remove"></i> </a>
                                                                </div> <?php } } }?>
                                                       </div>
                                                                                                <?php //echo form_error('order_no','<div class="form-error">','</div>');?>
                        </div>
                                                  <div style='color:red'><?php if(!empty($msg['images'])){ echo $msg['images'];}?></div>                                       
                    </div>
                                        
                                        <button type="submit" class="btn btn-info waves-effect waves-light" name='submit' value='submit'>Submit</button>
                                    </form>
                                </div>

                                


                            </div>

                    </div>
                    </div>
                </div>

</div>
            </div>

<?php include_once 'container/footer.php'; ?>