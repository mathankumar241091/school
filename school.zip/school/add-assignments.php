<?php include_once 'container/header.php';?>
    
            <div class="wrapper">
            <div class="container">
                <div class="row">
                    <div class="col-sm-12">
                        <div class="page-title-box">
                            <h4 class="page-title">Assign</h4>
                        </div>
                    </div>
                </div>
    

                <div class="row">
                    <div class="col-sm-12">
                        <div class="card-box">
                            <h4 class="m-t-0 header-title"><b>Assign</b></h4>
                            
                            <div class="row">
                                <div class="col-md-6">
                                    <?php 
                                    $student_detail=$STUDENT->selectNotAssign();
                                    $stu_options = '';$stu_select_box='';
                                    if(!empty($student_detail)){
                                                 foreach($student_detail as $student){
                                                    

                                                    $stu_options .= '<option value="' . $student['id'] . '">' . $student['name'] . '</option>';
   
                                                 }
                                                 
                                    }
                                    $stu_select_box = '<select name="student[]" class="form-control" multiple>' . $stu_options . '</select>';
                                    

                                    $teachers_details=$TEACHER->selectAll();
                                    $tea_options = '';$tea_select_box='';
                                    if(!empty($teachers_details)){
                                                 foreach($teachers_details as $teacher){
                                                    

                                                    $tea_options .= '<option value="' . $teacher['id'] . '">' . $teacher['name'] . '</option>';
   
                                                 }
                                                 
                                    }
                                    $tea_select_box = '<select name="teacher[]" class="form-control" multiple >' . $tea_options . '</select>';
                                    if(isset($_POST['submit'])){
                                         
                                         $msg=[];
                                         $student=$_POST['student'];
                                         $teacher=$_POST['teacher'];
                                         
                                         
                                         if(empty($student)){
                                             $msg['student']='Select Student Name';
                                         }
                                         if(empty($teacher)){
                                             $msg['teacher']='Select Student Date of birth';
                                         }
                                         
                                         if(empty($msg)){
                                             $add_data=array('student_id'=>$student,'teacher_id'=>$teacher);
                                             $add=$ASSIGN->add($add_data);
                                            // echo $add;exit;
                                             if(!empty($add)){
                                                 if($add==1){
                                                     echo '<div class="alert alert-icon alert-success alert-dismissible fade in" role="alert">
                                                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                                            <span aria-hidden="true">×</span>
                                                            </button>
                                                            <i class="mdi mdi-check-all"></i>
                                                            <strong>Success!</strong>Added Successfully
                                                            </div>';
                                                        header('refresh:2;url=Manage-assignments.php');
                                                 }
                                                 else{
                                                      echo '<div class="alert alert-icon alert-warning alert-dismissible fade in" role="alert">
                                                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                                            <span aria-hidden="true">×</span>
                                                             </button>
                                                            <i class="mdi mdi-block-helper"></i>
                                                            <strong>Failure!</strong>OOPS Error.</div>';
                                                         header('refresh:2;url=dashboard.php');
                                                 }
                                             }
                                             else{
                                                  echo '<div class="alert alert-icon alert-warning alert-dismissible fade in" role="alert">
                                                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                                            <span aria-hidden="true">×</span>
                                                             </button>
                                                            <i class="mdi mdi-block-helper"></i>
                                                            <strong>Failure!</strong>OOPS Error.</div>';
                                                   header('refesh:1;url:dashboard.php');
                                             }
                                         }
                                         
                                     }
                                    
                                    
                                    
                                    ?>
                                    
                                    
                                    <form class="form-horizontal" method='post' role="form">
                                        
                                        <div class="form-group">
                                            <label class="col-md-2 control-label">Student</label>
                                            <div class="col-md-10">
                                                <?php echo $stu_select_box;?>
                                            </div><br>
                                            
                                        </div>
                                         <div style= 'color:red'><?php if(!empty($msg['student'])){ echo $msg['teacher'];}?></div>

                                         <div class="form-group">
                                            <label class="col-md-2 control-label">Teacher</label>
                                            <div class="col-md-10">
                                                 <?php echo $tea_select_box;?>
                                            </div><br>
                                            
                                        </div>
                                         <div style= 'color:red'><?php if(!empty($msg['teacher'])){ echo $msg['teacher'];}?></div>
                                        
                                       
                                        
                                        
                                        
                                        <button type="submit" class="btn btn-info waves-effect waves-light" name='submit' value='submit'>Submit</button>
                                    </form>
                                </div>

                                


                            </div>

                    </div>
                    </div>
                </div>

</div>
            </div>

<?php include_once 'container/footer.php'; ?>