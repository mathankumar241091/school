<?php

include_once 'class.db.php';
class STUDENT extends DB{
    public $table=students;
    public function __construct() {
        parent::__construct();
        //var_dump($this->conn);
    }
    public function add($data){
         $dob = date("Y-m-d", strtotime($data['date']));
        $sql='INSERT INTO '.$this->table.' (name,dob,address,profile_image,created_at) VALUES ("'.$data['name'].'","'.$dob.'","'.$data['address'].'","'.$data['images'].'","'.date('y-m-d H:i:s').'") ';
        try{
            $result=$this->conn->prepare($sql);
            $result->execute();
             $row=$result->rowCount();
             if($row==1){
                 return 1;
             }
             else{
                  return 2;
             }
        }
        catch(PDOException $e){
             echo $e->getMessage();
        }
    }
    public function selectAll(){
        $sql='SELECT * FROM '.$this->table.'';
        try{
            $result=$this->conn->prepare($sql);
            $result->execute();
             $row=$result->rowCount();
             if($row>0){
                 while($rows=$result->fetch(PDO::FETCH_ASSOC)){
                     $_row[]=$rows;
                 }
                 return $_row;
             }
            
        }
        catch(PDOException $e){
             echo $e->getMessage();
        }
        
    }
    public function selectNotAssign(){
        $sql='SELECT s.* FROM students s LEFT JOIN assignments a ON s.id = a.student_id WHERE a.id IS NULL';
        try{
            $result=$this->conn->prepare($sql);
            $result->execute();
             $row=$result->rowCount();
             if($row>0){
                 while($rows=$result->fetch(PDO::FETCH_ASSOC)){
                     $_row[]=$rows;
                 }
                 return $_row;
             }
            
        }
        catch(PDOException $e){
             echo $e->getMessage();
        }
        
    }
    public function SelectId($_id){
       $sql='SELECT * FROM '.$this->table.' WHERE id="'.$_id.'"';
        try{
            $result=$this->conn->prepare($sql);
            $result->execute();
             $row=$result->rowCount();
             if($row>0){
                 while($rows=$result->fetch(PDO::FETCH_ASSOC)){
                     $_row[]=$rows;
                 }
                 return $_row;
             }
            
        }
        catch(PDOException $e){
             echo $e->getMessage();
        } 
    }
    public function Update($data){
        
        $dob = date("Y-m-d", strtotime($data['date']));
        unset($data['date']);
        $sql='UPDATE '.$this->table.' SET name=:name,address=:address,profile_image=:images,updated_at="'.date('y-m-d H:i:s').'",dob="'.$dob.'" WHERE id=:id ';
        try{
            //echo $sql;exit;
            $result=$this->conn->prepare($sql);
            $result->execute($data);
             $row=$result->rowCount();
             if($row==1){
                 return 1;
             }
             else{
                  return 2;
             }
        }
        catch(PDOException $e){
             echo $e->getMessage();
        }
    }
    public function Delete($_id){
        $check_id=$this->CheckId($_id);
      if(!empty($check_id)){
          if($check_id==1){
              $sql='DELETE FROM '.$this->table.' WHERE id="'.$_id.'"';
                try{
                    $result=$this->conn->prepare($sql);
                    $result->execute();
                     $row=$result->rowCount();
                     if($row==1){
                         return 1;
                     }
                     else{
                          return 2;
                     }
                }
                catch(PDOException $e){
                     echo $e->getMessage();
                }
          }
          else{
              return 3;
          }
      }
       
    }
     public function CheckId($_id){
         $sql='SELECT * FROM '.$this->table.' WHERE id="'.$_id.'"';
        try{
            $result=$this->conn->prepare($sql);
            $result->execute();
             $row=$result->rowCount();
             if($row==1){
                 return 1;
             }
             else{
                  return 2;
             }
        }
        catch(PDOException $e){
             echo $e->getMessage();
        }
     }
     
    
   
}