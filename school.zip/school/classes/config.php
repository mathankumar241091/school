<?php

define('HOST','localhost');
define('USER','root');
define('PASS','');
define('DBNAME','school');
define('ADMIN','admin');
define('STUDENT','students');
define('TEACHER','teachers');
define('ASSIGN','assignments');


