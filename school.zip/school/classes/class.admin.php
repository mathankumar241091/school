<?php

include_once 'class.db.php';
class ADMIN extends DB{
    public $table=ADMIN;
    public function __construct() {
        parent::__construct();
        //var_dump($this->conn);
    }
    public function init(){
        if(empty($_SESSION['admin'])){
            header('Location:index.php?msg=auth');
        }
    }
    public function login($data){
        $sql='SELECT * FROM '.$this->table.' WHERE name=:name AND password=:password AND status=1';
        try{
           $result=$this->conn->prepare($sql);
           $result->execute($data);
           $row=$result->rowCount();
          // echo 
           if($row==1){
               while($rows=$result->fetch(PDO::FETCH_ASSOC)){
                        //$_row=$rows;
                        $_SESSION['admin']=array('adminId'=>$rows['id'],'adminName'=>$rows['name'],'adminPass'=>$rows['password'],'adminStatus'=>$rows['status']);
                        
               }
               return 1;
           }
           else{
               return 2;
           }
           
        }
        catch(PDOException $e){
            echo $e->getMessage();
        }
    }
    public function Update($data){
        $sql='UPDATE '.$this->table.' SET name=:name,password=:password,updated="'.date('y-m-d H:i:s').'" WHERE id=:id';
        try{
           $result=$this->conn->prepare($sql);
           $result->execute($data);
           $row=$result->rowCount();
           if($row==1){
               return 1;
           }
           else{
               return 2;
           }
        }
        catch(PDOException $e){
            echo $e->getMessage();
        }
    }
    
    
}
