<?php
ob_start();
session_start();
include_once 'config.php';
class DB{
    public $host=HOST;
    public $user=USER;
    public $pass=PASS;
    public $db=DBNAME;
    public $conn=NULL;
    
    public function __construct() {
        try{
            $this->conn=new PDO("mysql:host=$this->host;dbname=$this->db",$this->user,$this->pass);
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            return $this->conn;
        }
        catch(PDOException $e){
            echo $e->getMessage();
        }
    }
}