<?php

include_once 'class.db.php';
class BANNER extends DB{
    public $table=BANNER;
    public function __construct() {
        parent::__construct();
        //var_dump($this->conn);
    }
    public function add($data){
        $sql='INSERT INTO '.$this->table.' (name,image,status,created) VALUES ("'.$data['name'].'","'.$data['image'].'",1,"'.date('y-m-d H:i:s').'") ';
        try{
            $result=$this->conn->prepare($sql);
            $result->execute();
             $row=$result->rowCount();
             if($row==1){
                 return 1;
             }
             else{
                  return 2;
             }
        }
        catch(PDOException $e){
             echo $e->getMessage();
        }
    }
    public function selectAll(){
        $sql='SELECT * FROM '.$this->table.' WHERE status=1';
        try{
            $result=$this->conn->prepare($sql);
            $result->execute();
             $row=$result->rowCount();
             if($row>0){
                 while($rows=$result->fetch(PDO::FETCH_ASSOC)){
                     $_row[]=$rows;
                 }
                 return $_row;
             }
            
        }
        catch(PDOException $e){
             echo $e->getMessage();
        }
        
    }
    public function SelectId($_id){
       $sql='SELECT * FROM '.$this->table.' WHERE id="'.$_id.'" AND status=1';
        try{
            $result=$this->conn->prepare($sql);
            $result->execute();
             $row=$result->rowCount();
             if($row>0){
                 while($rows=$result->fetch(PDO::FETCH_ASSOC)){
                     $_row[]=$rows;
                 }
                 return $_row;
             }
            
        }
        catch(PDOException $e){
             echo $e->getMessage();
        } 
    }
    public function Update($data){
        $sql='UPDATE '.$this->table.' SET name=:name,image=:image,updated="'.date('y-m-d H:i:s').'" WHERE id=:id ';
        try{
            $result=$this->conn->prepare($sql);
            $result->execute($data);
             $row=$result->rowCount();
             if($row==1){
                 return 1;
             }
             else{
                  return 2;
             }
        }
        catch(PDOException $e){
             echo $e->getMessage();
        }
    }
    public function seoUrl($string) {
            $string = strtolower($string);
                    $string = trim($string);
                    $string = preg_replace("/[^a-z0-9_\s-]/", "", $string);
            $string = preg_replace("/[\s-]+/", " ", $string);
            $string = preg_replace("/[\s_]/", "-", $string);
            return $string;
   }
    
    
}