<?php

include_once 'class.db.php';
class ASSIGN extends DB{
    public $table=assignments;
    public function __construct() {
        parent::__construct();
        //var_dump($this->conn);
    }
    public function add($data){
        //var_dump($data['teacher_id']);exit;
        $teacherList = $data['teacher_id'];
        $studentList = $data['student_id'];

        // Loop through each student and assign teachers in round-robin fashion
        $teacherCount = count($data['teacher_id']);
        //echo $teacherCount;exit;

        $i = 0;
        foreach ($data['student_id'] as $studentId) {
          // Check if the student is already assigned to a teacher
          $query = "SELECT * FROM assignments WHERE student_id = $studentId";
          $result = mysqli_query($conn, $query);
          if (mysqli_num_rows($result) > 0) {
            continue; // Skip this student as they are already assigned to a teacher
          }
          // Assign a teacher to this student in round-robin fashion
          $teacherId = $teacherList[$i % $teacherCount];
          $query = "INSERT INTO assignments (student_id, teacher_id) VALUES ($studentId, $teacherId)";
        
            $result=$this->conn->prepare($query);
            $result->execute($data);
            $row=$result->rowCount();
            if($row!=1){
                 return 2;
            }
                        
          $i++;
        }
        if($row==1){
             return 1;
        }
        
       
    }
    public function selectAll(){
        $sql='SELECT * FROM '.$this->table.'';
        try{
            $result=$this->conn->prepare($sql);
            $result->execute();
             $row=$result->rowCount();
             if($row>0){
                 while($rows=$result->fetch(PDO::FETCH_ASSOC)){
                     $_row[]=$rows;
                 }
                 return $_row;
             }
            
        }
        catch(PDOException $e){
             echo $e->getMessage();
        }
        
    }
    public function SelectId($_id){
       $sql='SELECT * FROM '.$this->table.' WHERE id="'.$_id.'"';
        try{
            $result=$this->conn->prepare($sql);
            $result->execute();
             $row=$result->rowCount();
             if($row>0){
                 while($rows=$result->fetch(PDO::FETCH_ASSOC)){
                     $_row[]=$rows;
                 }
                 return $_row;
             }
            
        }
        catch(PDOException $e){
             echo $e->getMessage();
        } 
    }
    
    public function Delete($_id){
        $check_id=$this->CheckId($_id);
      if(!empty($check_id)){
          if($check_id==1){
              $sql='DELETE FROM '.$this->table.' WHERE id="'.$_id.'"';
                try{
                    $result=$this->conn->prepare($sql);
                    $result->execute();
                     $row=$result->rowCount();
                     if($row==1){
                         return 1;
                     }
                     else{
                          return 2;
                     }
                }
                catch(PDOException $e){
                     echo $e->getMessage();
                }
          }
          else{
              return 3;
          }
      }
       
    }
     public function CheckId($_id){
         $sql='SELECT * FROM '.$this->table.' WHERE id="'.$_id.'"';
        try{
            $result=$this->conn->prepare($sql);
            $result->execute();
             $row=$result->rowCount();
             if($row==1){
                 return 1;
             }
             else{
                  return 2;
             }
        }
        catch(PDOException $e){
             echo $e->getMessage();
        }
     }
     
    
   
}