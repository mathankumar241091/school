<?php
 if(!empty($_FILES['file']['name'])) {
                    $uploaddir = './upload/event/';
                     $upload = 'upload/event/';
                    $temp = explode(".", $_FILES["file"]["name"]);
                    $filename = round(microtime(true)) . '.' . end($temp);
                    $_file = $uploaddir . $filename; 
                    $maxsize    = 2097152;
                    $acceptable = array('image/jpeg','image/jpg','image/png');
                    if( $_FILES["file"]["size"]>=$maxsize){
                        $msg='<div style="color:red">upload small image</div>';
                    }
                    elseif(!in_array($_FILES["file"]["type"], $acceptable)){
                        $msg='<div style="color:red">Only upload jpeg,jpg,png image</div>';
                    }
                    else{
                        if(file_exists($filename)){
                            $file_name=rand(10,1000).$filename;
                            $_file=$uploaddir.$file_name;
                            move_uploaded_file($_FILES['file']['tmp_name'], $_file);
                            $file=$upload.$file_name;
                            $arr=explode('.',$file_name);
                            $msg='<div class="ui-state-default" id="'.$arr[0].'"><a class="delete-image" id="'.$file.'" title="Delete" href="javascript:void(0);" rel="1" ><input type="hidden" id="cat_image" name="hidden_image[]" value="'.$file_name.'"><img height="100" width="100" src="'.$file.'" alt="" /><i class="glyphicon glyphicon-remove"></i> </a></div>';
                           
                        }
                        else{
                            move_uploaded_file($_FILES['file']['tmp_name'], $_file);
                             $file=$upload.$filename;
                             $arr=explode('.',$filename);
                            $msg='<div class="ui-state-default"  id="'.$arr[0].'"><a class="delete-image" id="'.$filename.'" title="Delete" href="javascript:void(0);" rel="1" ><input type="hidden" id="cat_image" name="hidden_image[]" value="'.$filename.'"><img height="100" width="100" src="'.$file.'" alt="" /><i class="glyphicon glyphicon-remove"></i> </a></div>';
                        }
                    }
                echo json_encode(array('status'=>1,'result'=>$msg));
          }
          else{
               echo json_encode(array('status'=>2,'result'=>'error'));
          }