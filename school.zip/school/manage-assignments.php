<?php include_once 'container/header.php';?>
<div class="wrapper">
            <div class="container">

                <!-- Page-Title -->
                <div class="row">
                    <div class="col-sm-12">
                        <div class="page-title-box">
                            
                            <h4 class="page-title">Manage Assign</h4>
                        </div>
                    </div>
                </div>
                <!-- end page title end breadcrumb -->

  <a href='add-assignments.php' class="btn btn-icon waves-effect waves-light btn-purple m-b-5"> add </a>
              <?php 
               if(!empty($_GET['msg'])){
                   if($_GET['msg']=='success'){
                       echo '<div class="alert alert-icon alert-success alert-dismissible fade in" role="alert">
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">×</span>
                        </button>
                        <i class="mdi mdi-block-helper"></i>
                        <strong>Success!</strong>Updated Successfully...</div>';
                       header('refresh:2;url=Manage-assignments.php');
                   }
               }
              
              ?>
                
                <div class="row">
                    <div class="col-sm-12">
                        <div class="card-box">
                            <div class="row">
                              <div class="col-lg-6">

                                    <div class="demo-box">
                                        <h4 class="m-t-0 header-title"><b>Manage Assign</b></h4>
                                        

                                        <table class="table table-bordered">
                                            <thead>
                                                <tr>
                                                   <th>STUDENT IMAGE</th>
                                                   <th>STUDENT NAME</th>
                                                    <th>TEACHER IMAGE</th>
                                                    <th>TEACHER NAME</th>
                                                      <th>ACTION</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php 
                                                 $assigns=$ASSIGN->selectAll();
                                                 if(!empty($assigns)){
                                                 foreach($assigns as $assign){
                                                 $student_detail=$STUDENT->SelectId($assign['student_id']);
                                                 $teacher_detail=$TEACHER->SelectId($assign['teacher_id']);
                                                 
                                                ?>
                                                
                                                <tr >
                                                    <td><?php $simage_path = "upload/event/".$student_detail[0]['profile_image'];if (file_exists($simage_path) && is_file($simage_path)) {
                                                        echo '<img src="'.$simage_path.'" width="36" height="36" alt="My Image">';
                                                    } else {
                                                        echo 'Image not found';
                                                    }?></td>
                                                    <td><?php if(!empty($student_detail[0]['name'])){ echo $student_detail[0]['name'];}?></td>
                                                    <td><?php $timage_path = "upload/event/".$teacher_detail[0]['profile_image'];if (file_exists($timage_path) && is_file($timage_path)) {
                                                        echo '<img src="'.$timage_path.'" width="36" height="36" alt="My Image">';
                                                    } else {
                                                        echo 'Image not found';
                                                    }?></td>
                                                    <td><?php if(!empty($teacher_detail[0]['name'])){ echo $teacher_detail[0]['name'];}?></td>
                                                    
                                                    <td><a href="delete-assignments.php?id=<?php echo $assign['id']; ?>"><i class="mdi mdi-delete"></i></a></td>
                                                </tr>
                                                 <?php } }
                                                 else{
                                                     echo 'No Assign list';
                                                 }?>
                                                
                                            </tbody>
                                        </table>
                                    </div>

                                </div>
                        </div>
                        </div>
                    </div>
                </div>
            </div>
</div>
                    

<?php include_once 'container/footer.php';?>