<?php
    if(!empty($_POST['file'])){
			$file=$_POST['file'];
			if(is_file('upload/event/'.$file)){
				 unlink('upload/event/'.$file);
                                 $arr=explode('.',$file);
				 $_Result=array('Status'=>'Success','File_Name'=>$arr[0]);
				 echo json_encode($_Result);
				 
			}
			else{
				$_Result=array('Status'=>'Error');
				echo json_encode($_Result);
			}
		}
		else{
			$_Result=array('Status'=>'Error'); 
			echo json_encode($_Result);	
	}