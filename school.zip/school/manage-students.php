<?php include_once 'container/header.php';?>
<div class="wrapper">
            <div class="container">

                <!-- Page-Title -->
                <div class="row">
                    <div class="col-sm-12">
                        <div class="page-title-box">
                            
                            <h4 class="page-title">Manage Students</h4>
                        </div>
                    </div>
                </div>
                <!-- end page title end breadcrumb -->

  <a href='add-students.php' class="btn btn-icon waves-effect waves-light btn-purple m-b-5"> add </a>
              <?php 
               if(!empty($_GET['msg'])){
                   if($_GET['msg']=='success'){
                       echo '<div class="alert alert-icon alert-success alert-dismissible fade in" role="alert">
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">×</span>
                        </button>
                        <i class="mdi mdi-block-helper"></i>
                        <strong>Success!</strong>Updated Successfully...</div>';
                       header('refresh:2;url=Manage-students.php');
                   }
               }
              
              ?>
                
                <div class="row">
                    <div class="col-sm-12">
                        <div class="card-box">
                            <div class="row">
                              <div class="col-lg-6">

                                    <div class="demo-box">
                                        <h4 class="m-t-0 header-title"><b>Manage Students</b></h4>
                                        

                                        <table class="table table-bordered">
                                            <thead>
                                                <tr>
                                                   <th>PROFILE IMAGE</th>
                                                    <th>NAME</th>
                                                    <th>DOB</th>
                                                    <th>ADDRESS</th>
                                                      <th>ACTION</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php 
                                                 $students=$STUDENT->selectAll();
                                                 if(!empty($students)){
                                                 foreach($students as $student){
                                                 //var_dump($All_Banner);
                                                ?>
                                                
                                                <tr >
                                                    <td><?php $image_path = "upload/event/".$student['profile_image'];if (file_exists($image_path) && is_file($image_path)) {
                                                        echo '<img src="'.$image_path.'" width="36" height="36" alt="My Image">';
                                                    } else {
                                                        echo 'Image not found';
                                                    }?></td>
                                                    <td><?php if(!empty($student['name'])){ echo $student['name'];} ?></td>
                                                    <td><?php if(!empty($student['dob'])){ echo date("d/m/Y", strtotime($student['dob']));} ?></td>
                                                    <td><?php if(!empty($student['address'])){ echo $student['address'];} ?></td>
                                                    <td><a href="edit-students.php?id=<?php echo $student['id']; ?>"><i class="mdi mdi-border-color"></i></a>--<?php if(isset($student['status'])){ if($student['status']==1){?><a href="status-students.php?id=<?php echo $student['id']; ?>"><i class="mdi mdi-check"></i></a><?php }else{ ?><a href="status-students.php?id=<?php echo $student['id']; ?>"><i class=" mdi mdi-close"></i></a><?php }} ?>--<a href="delete-students.php?id=<?php echo $student['id']; ?>"><i class="mdi mdi-delete"></i></a></td>
                                                </tr>
                                                 <?php } }
                                                 else{
                                                     echo 'No Students List';
                                                 }?>
                                                
                                            </tbody>
                                        </table>
                                    </div>

                                </div>
                        </div>
                        </div>
                    </div>
                </div>
            </div>
</div>
                    

<?php include_once 'container/footer.php';?>