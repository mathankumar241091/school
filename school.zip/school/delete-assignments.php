<?php
include_once 'classes/class.assign.php';
$ASSIGN=new ASSIGN;
if(!empty($_GET['id'])){
    $_id=$_GET['id'];
    $delete=$ASSIGN->Delete($_id);
    if(!empty($delete)){
        if($delete==1){
            echo '<div class="alert alert-icon alert-success alert-dismissible fade in" role="alert">
                  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                  <span aria-hidden="true">×</span>
                  </button>
                  <i class="mdi mdi-block-helper"></i>
                  <strong>Success!</strong>Deleted Successfully...</div>';
                 header('refresh:0;url=Manage-assignments.php?msg=success');
        }
    }
    
}