<?php include_once 'container/header.php';?>
<div class="wrapper">
            <div class="container">

                <!-- Page-Title -->
                <div class="row">
                    <div class="col-sm-12">
                        <div class="page-title-box">
                            
                            <h4 class="page-title">Manage Teachers</h4>
                        </div>
                    </div>
                </div>
                <!-- end page title end breadcrumb -->

  <a href='add-teachers.php' class="btn btn-icon waves-effect waves-light btn-purple m-b-5"> add </a>
              <?php 
               if(!empty($_GET['msg'])){
                   if($_GET['msg']=='success'){
                       echo '<div class="alert alert-icon alert-success alert-dismissible fade in" role="alert">
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">×</span>
                        </button>
                        <i class="mdi mdi-block-helper"></i>
                        <strong>Success!</strong>Updated Successfully...</div>';
                       header('refresh:2;url=Manage-teachers.php');
                   }
               }
              
              ?>
                
                <div class="row">
                    <div class="col-sm-12">
                        <div class="card-box">
                            <div class="row">
                              <div class="col-lg-6">

                                    <div class="demo-box">
                                        <h4 class="m-t-0 header-title"><b>Manage Teachers</b></h4>
                                        

                                        <table class="table table-bordered">
                                            <thead>
                                                <tr>
                                                   <th>PROFILE IMAGE</th>
                                                    <th>NAME</th>
                                                    <th>DOB</th>
                                                    <th>ADDRESS</th>
                                                      <th>ACTION</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php 
                                                 $teachers=$TEACHER->selectAll();
                                                 if(!empty($teachers)){
                                                 foreach($teachers as $teacher){
                                                 //var_dump($All_Banner);
                                                ?>
                                                
                                                <tr >
                                                    <td><?php $image_path = "upload/event/".$teacher['profile_image'];if (file_exists($image_path) && is_file($image_path)) {
                                                        echo '<img src="'.$image_path.'" width="36" height="36" alt="My Image">';
                                                    } else {
                                                        echo 'Image not found';
                                                    }?></td>
                                                    <td><?php if(!empty($teacher['name'])){ echo $teacher['name'];} ?></td>
                                                    <td><?php if(!empty($teacher['dob'])){ echo date("d/m/Y", strtotime($teacher['dob']));} ?></td>
                                                    <td><?php if(!empty($teacher['address'])){ echo $teacher['address'];} ?></td>
                                                    <td><a href="edit-teachers.php?id=<?php echo $teacher['id']; ?>"><i class="mdi mdi-border-color"></i></a>--<?php if(isset($teacher['status'])){ if($teacher['status']==1){?><a href="status-teachers.php?id=<?php echo $teacher['id']; ?>"><i class="mdi mdi-check"></i></a><?php }else{ ?><a href="status-teachers.php?id=<?php echo $teacher['id']; ?>"><i class=" mdi mdi-close"></i></a><?php }} ?>--<a href="delete-teachers.php?id=<?php echo $teacher['id']; ?>"><i class="mdi mdi-delete"></i></a></td>
                                                </tr>
                                                 <?php } }
                                                 else{
                                                     echo 'No Teachers List';
                                                 }?>
                                                
                                            </tbody>
                                        </table>
                                    </div>

                                </div>
                        </div>
                        </div>
                    </div>
                </div>
            </div>
</div>
                    

<?php include_once 'container/footer.php';?>